'use client';

import { useRouter } from 'next/navigation';

export default function Home() {
  const router = useRouter();

  const handleStart = () => {
    router.push('/dashboard');
  };

  return (
    <div className="flex h-screen flex-col items-center justify-center bg-gray-50">
      <h1 className="mb-4 text-4xl font-bold text-[#0056D2]">Personalized Learning Copilot</h1>
      <p className="mb-8 text-gray-600">Master DSA & DBMS with an AI Tutor</p>
      <button
        onClick={handleStart}
        className="rounded-xl bg-[#0056D2] px-8 py-4 text-lg font-semibold text-white shadow-lg transition hover:bg-blue-700"
      >
        Start Learning
      </button>
    </div>
  );
}
