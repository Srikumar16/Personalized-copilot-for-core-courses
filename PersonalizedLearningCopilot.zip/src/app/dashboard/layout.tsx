"use client";

import Sidebar from "@/components/Sidebar";
import { useAuth } from "@/components/AuthProvider";
import LearningProvider, { useLearning } from "@/components/LearningProvider";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import styles from "./layout.module.css";

export default function DashboardLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return (
        <LearningProvider>
            <DashboardContent>{children}</DashboardContent>
        </LearningProvider>
    );
}

function DashboardContent({ children }: { children: React.ReactNode }) {
    const { user, loading } = useAuth();
    const { currentCourse, progress } = useLearning();
    const router = useRouter();
    console.log("DashboardContent Render. Loading:", loading, "User:", user);

    useEffect(() => {
        if (!loading && !user) {
            router.push("/login");
        }
    }, [user, loading, router]);

    if (loading) {
        return (
            <div className="flex h-screen items-center justify-center">
                <div className="h-8 w-8 animate-spin rounded-full border-4 border-[#0056D2] border-t-transparent"></div>
            </div>
        );
    }

    return (
        <div className={styles.container}>
            <Sidebar currentCourse={currentCourse} progress={progress} />
            <main className={styles.mainContent}>
                {children}
            </main>
        </div>
    );
}
