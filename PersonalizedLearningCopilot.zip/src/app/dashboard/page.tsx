"use client";

import { useEffect, useRef } from "react";
import useLearningBot from "@/hooks/useLearningBot";
import ChatBubble from "@/components/Chat/ChatBubble";
import ActionButtons from "@/components/Chat/ActionButtons";
import styles from "./page.module.css";
import { Send } from "lucide-react";

export default function DashboardPage() {
    const { messages, suggestedActions, handleActionClick } = useLearningBot();
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages, suggestedActions]);

    return (
        <div className={styles.chatContainer}>
            <div className={styles.chatHeader}>
                <h1>Personalized Learning Copilot</h1>
            </div>

            <div className={styles.messagesArea}>
                {messages.map((msg) => (
                    <ChatBubble
                        key={msg.id}
                        message={msg.text}
                        sender={msg.sender}
                        codeSnippet={msg.codeSnippet}
                        language={msg.language}
                    />
                ))}

                {suggestedActions.length > 0 && (
                    <div className="flex justify-end mt-4 animate-fade-in">
                        <ActionButtons
                            options={suggestedActions}
                            onSelect={handleActionClick}
                        />
                    </div>
                )}

                <div ref={messagesEndRef} />
            </div>

            <div className={styles.inputArea}>
                <div className={styles.inputWrapper}>
                    <input
                        type="text"
                        placeholder="Type a message... (Use buttons for now)"
                        className={styles.input}
                        disabled
                    />
                    <button className={styles.sendButton} disabled>
                        <Send size={20} />
                    </button>
                </div>
                <p className={styles.disclaimer}>
                    AI can make mistakes. Please verify important information.
                </p>
            </div>
        </div>
    );
}
