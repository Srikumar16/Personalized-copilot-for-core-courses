import styles from './ActionButtons.module.css';

interface ActionOption {
    label: string;
    value: string;
    action: string; // Identifier for logic
}

interface ActionButtonsProps {
    options: ActionOption[];
    onSelect: (option: ActionOption) => void;
    disabled?: boolean;
}

export default function ActionButtons({ options, onSelect, disabled }: ActionButtonsProps) {
    if (!options || options.length === 0) return null;

    return (
        <div className={styles.container}>
            {options.map((option) => (
                <button
                    key={option.value}
                    onClick={() => onSelect(option)}
                    disabled={disabled}
                    className={styles.button}
                >
                    {option.label}
                </button>
            ))}
        </div>
    );
}
