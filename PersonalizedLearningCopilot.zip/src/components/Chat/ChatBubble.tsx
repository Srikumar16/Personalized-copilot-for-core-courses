import styles from './ChatBubble.module.css';

interface ChatBubbleProps {
    message: string;
    sender: 'bot' | 'user';
    codeSnippet?: string;
    language?: string;
}

export default function ChatBubble({ message, sender, codeSnippet, language }: ChatBubbleProps) {
    return (
        <div className={`${styles.bubbleContainer} ${sender === 'user' ? styles.user : styles.bot}`}>
            <div className={`${styles.bubble} ${sender === 'user' ? styles.userBubble : styles.botBubble}`}>
                <p className="whitespace-pre-wrap">{message}</p>

                {codeSnippet && (
                    <div className={styles.codeBlock}>
                        {language && <span className={styles.codeTitle}>{language}</span>}
                        <pre><code>{codeSnippet}</code></pre>
                    </div>
                )}

                <span className={styles.timestamp}>
                    {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
            </div>
        </div>
    );
}
