"use client";

import { createContext, useContext, useEffect, useState } from "react";
import { User, onAuthStateChanged } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { useRouter } from "next/navigation";

// Mock User for Demo Mode
const MOCK_USER: Partial<User> = {
    uid: 'demo-user-123',
    displayName: 'Demo Student',
    email: 'student@example.com',
    photoURL: '',
};

interface AuthContextType {
    user: User | null;
    loading: boolean;
    demoLogin: () => void;
}

const AuthContext = createContext<AuthContextType>({
    user: null,
    loading: true,
    demoLogin: () => { },
});

export const useAuth = () => useContext(AuthContext);

export default function AuthProvider({ children }: { children: React.ReactNode }) {
    const [user, setUser] = useState<User | null>(null);
    const [loading, setLoading] = useState(true);
    const router = useRouter();

    useEffect(() => {
        let unsubscribe: () => void = () => { };

        try {
            // Validation: If auth is empty or invalid, skip real auth
            // We check if 'auth' has any keys or if we can infer it's the mock empty object
            const isAuthInvalid = !auth || Object.keys(auth).length === 0;

            if (isAuthInvalid) {
                console.warn("Auth not initialized, enabling Demo Mode fallback.");
                setLoading(false);
                return;
            }

            unsubscribe = onAuthStateChanged(auth, (currentUser) => {
                setUser(currentUser);
                setLoading(false);
            });
        } catch (e) {
            console.error("Auth Initialization Error:", e);
            setLoading(false);
        }

        return () => unsubscribe();
    }, []);

    const demoLogin = () => {
        setUser(MOCK_USER as User);
        router.push('/dashboard');
    };

    return (
        <AuthContext.Provider value={{ user, loading, demoLogin }}>
            {!loading && children}
        </AuthContext.Provider>
    );
}
