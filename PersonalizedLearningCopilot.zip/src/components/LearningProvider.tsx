"use client";

import { createContext, useContext, useState } from "react";
import { Course, Level } from "@/lib/curriculum";

interface LearningContextType {
    currentCourse: Course | null;
    currentLevel: Level | null;
    currentTopicId: string | null;
    completedTopics: string[]; // List of topic IDs
    progress: number; // 0-100
    setCurrentCourse: (course: Course | null) => void;
    setCurrentLevel: (level: Level | null) => void;
    markTopicCompleted: (topicId: string) => void;
}

const LearningContext = createContext<LearningContextType>({
    currentCourse: null,
    currentLevel: null,
    currentTopicId: null,
    completedTopics: [],
    progress: 0,
    setCurrentCourse: () => { },
    setCurrentLevel: () => { },
    markTopicCompleted: () => { },
});

export const useLearning = () => useContext(LearningContext);

export default function LearningProvider({ children }: { children: React.ReactNode }) {
    const [currentCourse, setCurrentCourse] = useState<Course | null>(null);
    const [currentLevel, setCurrentLevel] = useState<Level | null>(null);
    const [currentTopicId, setCurrentTopicId] = useState<string | null>(null);
    const [completedTopics, setCompletedTopics] = useState<string[]>([]);

    const markTopicCompleted = (topicId: string) => {
        if (!completedTopics.includes(topicId)) {
            setCompletedTopics(prev => [...prev, topicId]);
        }
    };

    // Simplified progress calculation for MVP
    // In a real app, we'd calculate based on total topics in the selected course/level
    const progress = Math.min(100, (completedTopics.length / 5) * 100);

    return (
        <LearningContext.Provider value={{
            currentCourse,
            currentLevel,
            currentTopicId,
            completedTopics,
            progress,
            setCurrentCourse,
            setCurrentLevel,
            markTopicCompleted
        }}>
            {children}
        </LearningContext.Provider>
    );
}
