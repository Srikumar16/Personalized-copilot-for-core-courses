"use client";

import { useAuth } from "./AuthProvider";
import styles from "./Sidebar.module.css";
import { BookOpen, Database, BarChart2, LogOut, User as UserIcon } from "lucide-react";
import { auth } from "@/lib/firebase";

interface SidebarProps {
    currentCourse: 'DSA' | 'DBMS' | null;
    progress: number; // 0 to 100
}

export default function Sidebar({ currentCourse, progress }: SidebarProps) {
    const { user } = useAuth();

    const handleLogout = () => {
        try {
            if (auth && typeof auth.signOut === 'function') {
                auth.signOut();
            } else {
                console.warn("SignOut not available (Demo Mode)");
                window.location.reload(); // Force reload to clear state if needed
            }
        } catch (e) {
            console.error("Logout error", e);
        }
    };

    return (
        <aside className={styles.sidebar}>
            <div className={styles.header}>
                <div className={styles.avatar}>
                    {user?.photoURL ? (
                        <img src={user.photoURL} alt="User" className={styles.avatar} />
                    ) : (
                        <UserIcon size={24} />
                    )}
                </div>
                <div className={styles.userInfo}>
                    <h2>{user?.displayName || "Learner"}</h2>
                    <p>Student</p>
                </div>
            </div>

            <div className={styles.menu}>
                <div className={styles.sectionTitle}>Courses</div>

                <div className={`${styles.courseItem} ${currentCourse === 'DSA' ? styles.active : ''}`}>
                    <BookOpen size={20} />
                    <span>DSA Copilot</span>
                </div>

                <div className={`${styles.courseItem} ${currentCourse === 'DBMS' ? styles.active : ''}`}>
                    <Database size={20} />
                    <span>DBMS Copilot</span>
                </div>
            </div>

            <div className={styles.progressSection}>
                <div className="flex items-center justify-between text-sm mb-1">
                    <div className="flex items-center gap-2">
                        <BarChart2 size={16} />
                        <span>Course Progress</span>
                    </div>
                    <span className="font-semibold">{Math.round(progress)}%</span>
                </div>
                <div className={styles.progressBar}>
                    <div
                        className={styles.progressFill}
                        style={{ width: `${progress}%` }}
                    />
                </div>
            </div>

            <button onClick={handleLogout} className={styles.logoutBtn}>
                <LogOut size={18} />
                <span>Sign Out</span>
            </button>
        </aside>
    );
}
