"use client";

import { useState, useEffect, useRef } from 'react';
import { useLearning } from '@/components/LearningProvider';
import { CURRICULUM, Topic, Question, Course, Level } from '@/lib/curriculum';

export type ChatMessage = {
    id: string;
    sender: 'bot' | 'user';
    text: string;
    codeSnippet?: string;
    language?: string;
};

export type BotState =
    | 'IDLE'
    | 'AWAIT_COURSE'
    | 'AWAIT_LEVEL'
    | 'EXPLAINING_TOPIC'
    | 'QUIZ'
    | 'AWAIT_NEXT_ACTION';

export default function useLearningBot() {
    const {
        currentCourse,
        setCurrentCourse,
        setCurrentLevel,
        currentLevel,
        markTopicCompleted
    } = useLearning();

    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [botState, setBotState] = useState<BotState>('IDLE');
    const [currentTopic, setCurrentTopic] = useState<Topic | null>(null);
    const [quizIndex, setQuizIndex] = useState(0);
    const [score, setScore] = useState(0);
    const [suggestedActions, setSuggestedActions] = useState<{ label: string, value: string, action: string }[]>([]);

    // Helper to add message
    console.log("useLearningBot Render. Messages:", messages.length);

    const addMessage = (text: string, sender: 'bot' | 'user' = 'bot', codeSnippet?: string, language?: string) => {
        setMessages(prev => [...prev, {
            id: Math.random().toString(36).substr(2, 9),
            sender,
            text,
            codeSnippet,
            language
        }]);
    };

    // Initial Welcome
    useEffect(() => {
        if (messages.length === 0) {
            addMessage("Welcome to your Personalized Learning Copilot! 🚀\nI can help you master DSA or DBMS.");
            addMessage("Which subject would you like to start with?");
            setSuggestedActions([
                { label: "DSA", value: "DSA", action: "SELECT_COURSE" },
                { label: "DBMS", value: "DBMS", action: "SELECT_COURSE" }
            ]);
            setBotState('AWAIT_COURSE');
        }
    }, []);

    const handleUserAction = (value: string, actionType: string) => {
        // Add user response bubble
        addMessage(value, 'user');
        setSuggestedActions([]); // Clear buttons

        switch (botState) {
            case 'AWAIT_COURSE':
                if (value === 'DSA' || value === 'DBMS') {
                    setCurrentCourse(value as Course);
                    addMessage(`Great choice! We'll focus on ${value}.`);
                    addMessage("What is your current experience level?");
                    setSuggestedActions([
                        { label: "Beginner", value: "Beginner", action: "SELECT_LEVEL" },
                        { label: "Intermediate", value: "Intermediate", action: "SELECT_LEVEL" },
                        { label: "Advanced", value: "Advanced", action: "SELECT_LEVEL" }
                    ]);
                    setBotState('AWAIT_LEVEL');
                }
                break;

            case 'AWAIT_LEVEL':
                if (['Beginner', 'Intermediate', 'Advanced'].includes(value)) {
                    const level = value as Level;
                    setCurrentLevel(level);
                    addMessage(`Got it! Starting with ${currentCourse} - ${level} topics.`);
                    startTopic(currentCourse!, level);
                }
                break;

            case 'QUIZ':
                handleQuizAnswer(value);
                break;

            case 'AWAIT_NEXT_ACTION':
                if (actionType === 'NEXT_TOPIC') {
                    // Ideally find next topic logic here
                    // For MVP, just re-selecting same topic or loop
                    addMessage("Moving to the next module...");
                    startTopic(currentCourse!, currentLevel!);
                } else if (actionType === 'REVISE') {
                    addMessage("Okay, let's review the concept again.");
                    explainTopic(currentTopic!);
                } else if (actionType === 'SWITCH_COURSE') {
                    // Reset
                    setBotState('AWAIT_COURSE');
                    addMessage("Which subject would you like to switch to?");
                    setSuggestedActions([
                        { label: "DSA", value: "DSA", action: "SELECT_COURSE" },
                        { label: "DBMS", value: "DBMS", action: "SELECT_COURSE" }
                    ]);
                }
                break;
        }
    };

    const startTopic = (course: Course, level: Level) => {
        // Find first available topic or next uncompleted one
        const topics = CURRICULUM[course][level];
        if (topics && topics.length > 0) {
            // For MVP just picking the first one or random
            const topic = topics[0];
            setCurrentTopic(topic);
            explainTopic(topic);
        } else {
            addMessage("No topics found for this level yet.");
        }
    };

    const explainTopic = (topic: Topic) => {
        setTimeout(() => {
            setBotState('EXPLAINING_TOPIC');
            addMessage(`Today's Topic: ${topic.title}`);
            addMessage(topic.content);
            if (topic.codeSnippet) {
                addMessage("Here is an example:", 'bot', topic.codeSnippet, topic.language);
            }

            setTimeout(() => {
                addMessage("Ready for a quick quiz?");
                setSuggestedActions([
                    { label: "I'm Ready!", value: "Ready", action: "START_QUIZ" }
                ]);
            }, 1000);
        }, 500);
    };

    // Special handler because "I'm Ready" isn't a state transition strictly
    // We intercept the action in the UI or handle it here.
    // Let's refine handleUserAction to handle START_QUIZ if we are in EXPLAINING_TOPIC

    const handleActionClick = (option: { label: string, value: string, action: string }) => {
        if (option.action === 'START_QUIZ') {
            addMessage(option.label, 'user');
            setSuggestedActions([]);
            startQuiz();
            return;
        }
        handleUserAction(option.value, option.action);
    };

    const startQuiz = () => {
        setBotState('QUIZ');
        setQuizIndex(0);
        setScore(0);
        askQuestion(0);
    };

    const askQuestion = (index: number) => {
        if (!currentTopic || !currentTopic.questions[index]) return;

        const q = currentTopic.questions[index];
        addMessage(`Q${index + 1}: ${q.text}`);

        setSuggestedActions(q.options.map((opt, i) => ({
            label: opt,
            value: i.toString(), // We pass index as value for checking
            action: 'ANSWER_QUIZ'
        })));
    };

    const handleQuizAnswer = (answerIndexStr: string) => {
        const answerIndex = parseInt(answerIndexStr);
        const q = currentTopic?.questions[quizIndex];
        const isCorrect = q?.correctAnswer === answerIndex;

        if (isCorrect) {
            addMessage("✅ Correct!");
            setScore(s => s + 1);
        } else {
            addMessage(`❌ Incorrect. The right answer was: ${q?.options[q.correctAnswer]}`);
        }

        const nextIndex = quizIndex + 1;
        if (currentTopic && nextIndex < currentTopic.questions.length) {
            setQuizIndex(nextIndex);
            setTimeout(() => askQuestion(nextIndex), 800);
        } else {
            finishQuiz(score + (isCorrect ? 1 : 0)); // Pass updated score
        }
    };

    const finishQuiz = (finalScore: number) => {
        const total = currentTopic?.questions.length || 0;
        const percentage = (finalScore / total) * 100;

        addMessage(`Quiz Completed! You scored ${finalScore}/${total} (${Math.round(percentage)}%)`);

        if (percentage >= 70) {
            addMessage("🎉 Great job! You've mastered this topic.");
            if (currentTopic) markTopicCompleted(currentTopic.id);

            setBotState('AWAIT_NEXT_ACTION');
            setSuggestedActions([
                { label: "Next Topic", value: "Next", action: "NEXT_TOPIC" },
                { label: "Switch Course", value: "Switch", action: "SWITCH_COURSE" }
            ]);
        } else {
            addMessage("Looks like you need a bit more practice. Let's review the concept.");
            setBotState('AWAIT_NEXT_ACTION');
            setSuggestedActions([
                { label: "Revise Topic", value: "Revise", action: "REVISE" },
                { label: "Switch Course", value: "Switch", action: "SWITCH_COURSE" }
            ]);
        }
    };

    return {
        messages,
        suggestedActions,
        handleActionClick,
        inputValue: '' // In case we add free text later
    };
}
