import { initializeApp, getApps, getApp, FirebaseApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, Auth } from "firebase/auth";

const firebaseConfig = {
    apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
    authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
    projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
    storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
    messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
    appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};

// Initialize Firebase
let app: FirebaseApp;
let auth: Auth;
let googleProvider: GoogleAuthProvider;

try {
    // Check if config is valid (at least apiKey)
    if (firebaseConfig.apiKey && firebaseConfig.apiKey !== 'your_api_key') {
        app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
        auth = getAuth(app);
        googleProvider = new GoogleAuthProvider();
    } else {
        // If no config (e.g. during build or initial setup), create a dummy object or warn
        // preventing the build from crashing
        console.warn("Firebase config missing or invalid. Auth services will not work.");

        // We can't really return a valid Auth object without a real app.
        // Casting to any to satisfy TS during build if needed
        app = {} as FirebaseApp;
        auth = {} as Auth;
        googleProvider = {} as GoogleAuthProvider;
    }
} catch (error) {
    console.error("Firebase initialization error:", error);
    app = {} as FirebaseApp;
    auth = {} as Auth;
    googleProvider = {} as GoogleAuthProvider;
}

export { auth, googleProvider };
