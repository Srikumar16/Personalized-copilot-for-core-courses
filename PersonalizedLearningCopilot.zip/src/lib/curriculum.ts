export type Level = 'Beginner' | 'Intermediate' | 'Advanced';
export type Course = 'DSA' | 'DBMS';

export interface Question {
    id: string;
    text: string;
    options: string[];
    correctAnswer: number; // 0-indexed
}

export interface Topic {
    id: string;
    title: string;
    content: string; // The explanation
    codeSnippet?: string; // Optional code example
    language?: 'java' | 'sql';
    questions: Question[];
}

export const CURRICULUM: Record<Course, Record<Level, Topic[]>> = {
    DSA: {
        Beginner: [
            {
                id: 'dsa-beg-1',
                title: 'Introduction to Arrays',
                content: `An Array is a collection of items stored at contiguous memory locations. The idea is to store multiple items of the same type together. This makes it easier to calculate the position of each element by simply adding an offset to a base value, i.e., the memory location of the first element of the array.`,
                language: 'java',
                codeSnippet: `// Declaring an array in Java
int[] arr = new int[5];
arr[0] = 10;
arr[1] = 20;
System.out.println(arr[0]); // Output: 10`,
                questions: [
                    {
                        id: 'dsa-beg-1-q1',
                        text: 'What is the index of the first element in an array in Java?',
                        options: ['0', '1', '-1', 'Undefined'],
                        correctAnswer: 0
                    },
                    {
                        id: 'dsa-beg-1-q2',
                        text: 'How are array elements stored in memory?',
                        options: ['Randomly', 'Contiguously', 'Linked together', 'In a stack'],
                        correctAnswer: 1
                    },
                    {
                        id: 'dsa-beg-1-q3',
                        text: 'If an array has size 5, what is the index of the last element?',
                        options: ['5', '4', '6', 'Unknown'],
                        correctAnswer: 1
                    }
                ]
            },
            // Add more topics if needed
        ],
        Intermediate: [
            {
                id: 'dsa-int-1',
                title: 'Linked Lists Basics',
                content: `A Linked List is a linear data structure where elements are not stored at contiguous memory locations. The elements in a linked list are linked using pointers. Each node contains data and a reference (link) to the next node in the sequence.`,
                language: 'java',
                codeSnippet: `class Node {
    int data;
    Node next;
    Node(int d) { data = d; next = null; }
}`,
                questions: [
                    {
                        id: 'dsa-int-1-q1',
                        text: 'What does each node in a singly linked list contain?',
                        options: ['Only Data', 'Data and Reference to next node', 'Data and Reference to previous node', 'None of the above'],
                        correctAnswer: 1
                    },
                    {
                        id: 'dsa-int-1-q2',
                        text: 'Which allows faster access to elements: Array or Linked List?',
                        options: ['Array', 'Linked List', 'Both are same', 'Depends on data type'],
                        correctAnswer: 0
                    },
                    {
                        id: 'dsa-int-1-q3',
                        text: 'What is the value of "next" in the last node of a linked list?',
                        options: ['0', 'first node', 'null', 'garbage value'],
                        correctAnswer: 2
                    }
                ]
            }
        ],
        Advanced: []
    },
    DBMS: {
        Beginner: [
            {
                id: 'dbms-beg-1',
                title: 'Introduction to SQL',
                content: `SQL (Structured Query Language) is a standard language for storing, manipulating and retrieving data in databases. A relational database manages data in tables (rows and columns).`,
                language: 'sql',
                codeSnippet: `SELECT * FROM Students WHERE Age > 18;`,
                questions: [
                    {
                        id: 'dbms-beg-1-q1',
                        text: 'What does SQL stand for?',
                        options: ['Structured Question Language', 'Structured Query Language', 'Simple Query Language', 'Standard Query List'],
                        correctAnswer: 1
                    },
                    {
                        id: 'dbms-beg-1-q2',
                        text: 'Which command is used to retrieve data from a database?',
                        options: ['GET', 'OPEN', 'SELECT', 'FETCH'],
                        correctAnswer: 2
                    },
                    {
                        id: 'dbms-beg-1-q3',
                        text: 'A table consists of?',
                        options: ['Rows and Columns', 'Keys and Values', 'Graphs', 'Nodes'],
                        correctAnswer: 0
                    }
                ]
            }
        ],
        Intermediate: [],
        Advanced: []
    }
};
